package com.neosoft.main.Controller;

public class ControllerException 
{

	public ControllerException( Object errorCode, Object errorMessage) 
	{
		
	}

}
