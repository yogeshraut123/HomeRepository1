package com.neosoft.main.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.neosoft.main.Model.User;

import com.neosoft.main.Service.HomeService;

@RestController
public class HomeController {
	@Autowired
	HomeService hs;

	@PostMapping("/saveUser")
	public String register(@RequestBody User u) {
		hs.saveUser(u);
		return "Data Saved";
	}

	@DeleteMapping("/delete/{uid}")
	public String delete(@PathVariable("uid") Integer uid) {
		hs.deleteUser(uid);
		return "User deleted";
	}

	@PutMapping("/user/{uid}")
	public String updatedata(@RequestBody User u) {

		hs.updatedata(u);
		return "update data successfully";

	}

	@GetMapping("/User/userName")
	public ResponseEntity<List<User>> getUserByName(@RequestParam String userName) {
		return new ResponseEntity(hs.findUserByUname(userName), HttpStatus.OK);
	}

	@GetMapping("/getUserBysortDob")
	public ResponseEntity<?> getUserByUsingSortingField() throws BusinessException {
		try {
			List<User> list = hs.getUserByUsingSortingField();
			if (!list.isEmpty()) {
				return new ResponseEntity<List<User>>(list, HttpStatus.OK);
			} else {
				return new ResponseEntity<String>("list is empty", HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			ControllerException ce = new ControllerException("611", "Something went wrong in controller");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);

		}

	}

	@GetMapping("/getUserBysortJoinDate")
	public ResponseEntity<?> getUserByUsingSortingFieldJoin() throws BusinessException {
		try {
			List<User> list = hs.getUserByUsingSortingFieldJoiningDate();
			if (!list.isEmpty()) {
				return new ResponseEntity<List<User>>(list, HttpStatus.OK);
			} else {
				return new ResponseEntity<String>("list is empty", HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			ControllerException ce = new ControllerException("611", "Something went wrong in controller");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);

		}

	}

}
