package com.neosoft.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringRestApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApi2Application.class, args);
	}

}
