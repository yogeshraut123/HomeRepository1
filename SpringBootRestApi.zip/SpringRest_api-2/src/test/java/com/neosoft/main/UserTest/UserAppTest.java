package com.neosoft.main.UserTest;

import org.junit.jupiter.api.Test;


public class UserAppTest {

	@Test
	public void test() {
		
	}
}
